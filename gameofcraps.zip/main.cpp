#include <iostream>
#include <cstdlib>
#include <time.h>

using namespace std;
int d1;
int d2;
int p;
int t;
int nt;
int c = 100;
int w;



void die(){

    
    d1 = rand() % 6 + 1;
    d2 = rand() % 6 + 1;
}

int Point(){
    p = t;
        cout << " Your point: " << p << endl;
        cout << endl;
            
        do{
            
             die();
            nt = d1 + d2;
            cout << "First roll: " << d1 << endl;
            cout << "Second roll: " << d2 << endl;
            cout << "Total: " << nt << endl;
            cout << endl;
            if(nt == p){
                cout << "Congrats you made your point! You win!" << endl;
                c += w;
                return c;
            }else if(nt == 7){
                cout << "You got a 7 and not your point, you lose" << endl;
                c -= w;
                return c;
            }
        } while(nt != p || nt != 7);
            
        
   return 0;     
}
void playGame(){

    cout << "You have " << c << " credits, how much would you like to wager? ";
    cin >> w;
    if(w < 0 || w > c){
        cout << "Please input an actual bet ";
        cin >> w;
    }
    c >> w;

    srand(time(0));
    die();
    t = d1 + d2;
    cout << d1 << endl;
    cout << d2 << endl;
    cout << t <<endl;
    
        if(t == 7 || t == 11){
        cout << " Congrats you win " << endl;
        c += w;
    }else if(t == 2||t == 3 || t == 12){
        cout << " Rolled Craps, you lose " << endl;
        c -= w;
    }else{
        Point();
          
    }
    }
    


int main( ) {
  char ans;
  bool done = false;
  while ( ! done ) {
         playGame();   // YOU MUST WRITE THIS FUNCTION
         cout << "Total Credits: " << c << endl;
         if(c == 0){
            cout << "You have no more credits to wager, game over" << endl;
            return 0;
         }
         cout << " Play again (y/n) ? ";
         cin >> ans;
         if ( ans == 'n' || ans == 'N') done = true;
             else done = false;
  }
  return 0;
}