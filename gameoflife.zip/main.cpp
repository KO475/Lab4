#include <iostream>
#include <ncurses.h>
#include <vector>
#include <string>
#include <unistd.h>
#include "prog2"

using namespace std;
using V = vector<char>;
using M = vector<V>;


extern M A;
extern bool isValid(int i, int j);
extern int Neighbours(int i, int j, M A);
extern void nextGen();
extern void display();
extern void firstGen();
extern void gameOfLife();


int main(){
    initscr();
    noecho();
    cbreak();
    keypad(stdscr, TRUE);
    curs_set(0);
    mouseinterval(3);
    mousemask(ALL_MOUSE_EVENTS, NULL);

   
    firstGen();
    gameOfLife();

    nextGen();

    display();
    endwin();

    return 0;

}